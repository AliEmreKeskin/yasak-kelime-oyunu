﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Belirleyeceğiniz sayı aralığındaki, belirlediğiniz özelliklere sahip sayıların toplamı bulunacak");
            Console.Write("Sayı aralığı başlangıcını giriniz: ");
            int a=Convert.ToInt32(Console.ReadLine());
            Console.Write("Sayı aralığı bitişini giriniz: ");
            int b=Convert.ToInt32(Console.ReadLine());
            Console.Write("Bölünebilinilecek sayıyı giriniz giriniz: ");
            int c=Convert.ToInt32(Console.ReadLine());
            Console.Write("Bölünebilinilemeyecek sayıyı giriniz giriniz: ");
            int d=Convert.ToInt32(Console.ReadLine());
            int x = 0;
            for (int i = a; i <= b; i++)
            {
                if (i % c == 0 & i % d != 0)
                {
                    x = x + i;
                } 
            }
            Console.WriteLine("Belirlediğiniz özellikte sayıların toplamı=" + x);
            Console.ReadKey();
        }
    }
}
